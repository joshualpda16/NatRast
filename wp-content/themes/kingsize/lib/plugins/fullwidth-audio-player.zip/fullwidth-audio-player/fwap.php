<div class="fap-wrapper">

	<div class="fap-preloader">

		<div>
			<div class="fap-spinner">
				<div class="fap-double-bounce1"></div>
				<div class="fap-double-bounce2"></div>
			</div>
			<span class="fap-loading-text">Loading Playlist</span>
		</div>
	</div>

	<div class="fap-main">

		<div class="fap-toggle">+</div>

		<div class="fap-toolbar fap-clearfix">

			<div class="fap-track-info fap-clearfix">

				<div class="fap-cover-wrapper">
					<img src="" />
				</div>

				<div class="fap-meta">

					<div class="fap-title">Track Title</div>
					<div class="fap-sub-title">Sub Title</div>
					<div class="fap-links">

						<a href="" target="_blank" class="fap-share-fb">Share On Facebook</a>
						<a href="" target="_blank" class="fap-share-tw">Share On Twitter</a>
						<a href="" target="_blank" class="fap-download">Download</a>
						<a href="" target="_blank" class="fap-sc">
							<span class="fap-icon-soundcloud"></span> Soundcloud
						</a>

					</div>
				</div>

			</div>

			<div class="fap-controls">

				<div class="fap-main-controls">

					<div class="fap-play-controls">

						<div class="fap-skip-previous">
							<span class="fap-icon-skip-previous"></span>
						</div>
						<div class="fap-play-pause">
							<span class="fap-icon-play"></span>
							<span class="fap-icon-pause fap-hidden"></span>
						</div>
						<div class="fap-skip-next">
							<span class="fap-icon-skip-next"></span>
						</div>

					</div>
					<div class="fap-volume-wrapper">

						<div class="fap-volume-scrubber">
							<div class="fap-volume-indicator"></div>
						</div>
						<span class="fap-volume-icon">
							<span class="fap-icon-volume"></span>
						</span>


					</div>

				</div>
				<div class="fap-timebar fap-clearfix">

					<div class="fap-loading-bar">
						<div class="fap-buffer-bar"></div>
						<div class="fap-progress-bar"></div>
					</div>
					<span class="fap-current-time">00:00:00</span>
					<span class="fap-total-time">00:00:00</span>

				</div>

			</div>

			<div class="fap-actions">

				<div class="fap-open-popup">
					<span class="fap-icon-popup"></span>
				</div>

				<div class="fap-toggle-playlist">
					<span class="fap-icon-playlist"></span>
				</div>

			</div>

		</div>

		<div class="fap-playlist-wrapper">

			<div class="fap-playlist-actions">
				<span class="fap-shuffle">
					<span class="fap-icon-shuffle"></span>
				</span>
				<span class="fap-empty">
					<span class="fap-icon-empty"></span>
				</span>
			</div>
			<div class="fap-scroll-area">
				<div class="fap-list"></div>
			</div>

		</div>

	</div>

</div>