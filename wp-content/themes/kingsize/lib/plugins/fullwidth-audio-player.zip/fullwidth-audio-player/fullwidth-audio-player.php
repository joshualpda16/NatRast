<?php
/*
Plugin Name: Fullwidth Audio Player
Plugin URI: http://radykal.de/wordpress-plugins/fullwidth-audio-player/
Description: Add a fixed audio player to any page on your wordpress site. Create your playlists and add them into the player or anywhere in your wordpress site.
Version: 2.0.0
Author: Rafael Dery
*/

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

if (!defined('FAP_PLUGIN_ROOT_PHP'))
    define( 'FAP_PLUGIN_ROOT_PHP', dirname(__FILE__).'/'.basename(__FILE__)  );

if( !class_exists('FullwidthAudioPlayer') ) {

	class FullwidthAudioPlayer {

		//constants
		const CAPABILITY = 'edit_fullwidth_audio_player';
		const VERSION = '2.0.0';
		const VERSION_FIELD_NAME = 'fullwidth_audio_player_version';
		const DEBUG = false;

		private $mp3_dir;
		private $mp3_dir_url;

		//Constructer
		public function __construct() {

			//the path and url to the mp3 directory
			$this->mp3_dir =  WP_CONTENT_DIR . '/uploads/fwap-mp3/';
			$this->mp3_dir_url = WP_CONTENT_URL . '/uploads/fwap-mp3/';

			require_once(__DIR__.'/inc/global-functions.php');
			require_once(__DIR__.'/inc/class-install.php');
			require_once(__DIR__.'/inc/class-frontend.php');


			//action hooks
			add_action( 'after_setup_theme', array( &$this, 'setup_fap' ) );
			add_action( 'init', array( &$this,'init_plugin') );
			add_action( 'admin_init', array( &$this,'init_admin' ) );

			add_action( 'admin_menu', array( &$this,'add_pp_sub_pages' ) );
			add_action( 'admin_enqueue_scripts', array( &$this, 'enqueue_admin_styles_scripts') );
			add_action( 'save_post', array( &$this,'update_custom_meta_fields' ) );
			add_action( 'manage_posts_custom_column', array( &$this, 'posts_custom_column' ), 10, 2 );
			add_action( 'restrict_manage_posts', array( &$this,'playlist_filter_list' ) );
			add_filter( 'parse_query', array( &$this,'perform_filtering' ) );

			//filters
			add_filter( 'manage_track_posts_columns', array( &$this, 'add_custom_columns' ) );

			if(!file_exists($this->mp3_dir))
				mkdir($this->mp3_dir);

			//uncomment next line to delete the options from the DB
			//delete_option('fap_options');

		}

		public function setup_fap() {

			$fap_options = get_option('fap_options');
			$general_options = $fap_options['general'];

			add_theme_support('post-thumbnails');

			//CUSTOM POST TYPES
			$pp_labels = array(
			  'name' => _x('Tracks', 'post type general name', 'radykal'),
			  'singular_name' => _x('Track', 'post type singular name', 'radykal'),
			  'add_new' => _x('Add New', 'track', 'radykal'),
			  'add_new_item' => __('Add New Track', 'radykal'),
			  'edit_item' => __('Edit Track', 'radykal'),
			  'new_item' => __('New Track', 'radykal'),
			  'all_items' => __('All Tracks', 'radykal'),
			  'view_item' => __('View Track', 'radykal'),
			  'search_items' => __('Search Tracks', 'radykal'),
			  'not_found' =>  __('No Tracks found', 'radykal'),
			  'not_found_in_trash' => __('No Tracks found in Trash', 'radykal'),
			  'parent_item_colon' => '',
			  'menu_name' => 'Fullwidth Audio Player'

			);

			$pp_args = array(
			  'labels' => $pp_labels,
			  'public' => fap_int_to_bool($general_options['public_posts']),
			  'exclude_from_search' => fap_int_to_bool($general_options['exclude_from_search']),
			  'show_ui' => true,
			  'show_in_menu' => true,
			  'has_archive' => true,
			  'hierarchical' => false,
			  'menu_icon' => 'dashicons-format-audio',
			  'supports' => array('title','editor','thumbnail', 'page-attributes', 'comments', 'custom_fields'),
			  'register_meta_box_cb' => array(&$this, 'add_meta_boxes')
			);

			register_post_type( 'track', $pp_args );


			//TAXONOMIES
			$tax_playlists_labels = array(
			  'name' => _x( 'Playlists', 'taxonomy general name', 'radykal' ),
			  'singular_name' => _x( 'Playlist', 'taxonomy singular name', 'radykal' ),
			  'search_items' =>  __( 'Search Playlists', 'radykal' ),
			  'all_items' => __( 'All Playlists', 'radykal' ),
			  'parent_item' => __( 'Parent Playlist', 'radykal' ),
			  'parent_item_colon' => __( 'Parent Playlist:', 'radykal' ),
			  'edit_item' => __( 'Edit Playlist', 'radykal' ),
			  'update_item' => __( 'Update Playlist', 'radykal' ),
			  'add_new_item' => __( 'Add New Playlist', 'radykal' ),
			  'new_item_name' => __( 'New Playlist Name', 'radykal' ),
			  'menu_name' => __( 'Playlists', 'radykal' ),
			);

			register_taxonomy('dt_playlist', 'track', array(
			  'hierarchical' => true,
			  'labels' => $tax_playlists_labels,
			  'show_ui' => true,
			  'query_var' => true,
			  'rewrite' => array( 'slug' => 'playlist' ),
			));

		}

		public function init_plugin() {

			$options = get_option('fap_options');
			$general_options = $options['general'];

			add_image_size( 'fap-list-thumbnail', $general_options['list_image_width'], $general_options['list_image_height'], true );
			add_image_size( 'fap-grid-thumbnail', $general_options['grid_image_width'], $general_options['grid_image_height'], true );

			//load textdomain
			load_plugin_textdomain('radykal', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/');

		}

		public function init_admin() {

			require_once(__DIR__.'/admin/class-admin-mp3-directory.php');

			$role = get_role( 'administrator' );
			$role->add_cap( FullwidthAudioPlayer::CAPABILITY );

		}

		public function add_pp_sub_pages() {

			//add options page
			$options_page = add_submenu_page( 'edit.php?post_type=track', __('Options', 'radykal'), __('Options', 'radykal'), FullwidthAudioPlayer::CAPABILITY, 'fap-options', array($this, 'options_admin_page') );
			add_action( "load-{$options_page}", array( &$this,'load_options_page' ) );

			add_submenu_page( 'edit.php?post_type=track', __('MP3 Directory', 'radykal'), __('MP3 Directory', 'radykal'), FullwidthAudioPlayer::CAPABILITY, 'fap-mp3-directory', array($this, 'mp3_directory_page') );

		}

		//enqueue js and css for the admin
		public function enqueue_admin_styles_scripts( $hook ) {

			if($hook == 'track_page_fap-options') {
				wp_enqueue_style( 'spectrum-colorpicker', plugins_url( '/admin/css/spectrum.css', __FILE__ ) );
				wp_enqueue_style( 'fap-options', plugins_url( '/admin/css/options.css', __FILE__ ), array('thickbox') );

				wp_enqueue_script( 'spectrum-colorpicker', plugins_url( '/admin/js/spectrum.js', __FILE__ ) );
				wp_enqueue_script( 'fap-options', plugins_url( '/admin/js/options.js', __FILE__ ), array('media-upload', 'thickbox') );
			}
			else if($hook == 'track_page_fap-mp3-directory') {
				wp_enqueue_style( 'fap-mp3-directory', plugins_url( '/admin/css/mp3-directory.css', __FILE__ ) );
				wp_enqueue_script( 'jquery-ui-sortable', 'wp-ajax-response' );
			}

		}

		public function mp3_directory_page() {

			require_once(dirname(__FILE__) . '/admin/mp3-directory.php');
		}



		public function options_admin_page () {

			global $pagenow;

			//get options
			$fap_options = get_option('fap_options');
			$general_options = $fap_options['general'];
			$audioplayer_options = $fap_options['audioplayer'];
			$audioplayer_options = fap_check_options_availability($audioplayer_options);
			?>

			<div class="wrap" id="fap-options-wrap">
				<h2><?php _e( 'Options', 'radykal' ); ?></h2>

				<?php

				    //get tab
				    if ( isset ( $_GET['tab'] ) )
				    	$tab = $_GET['tab'];
					else
						$tab = 'general';

					$this->options_admin_tabs($tab);

					if ( isset($_GET['updated']) && 'true' == esc_attr( $_GET['updated'] ) )
						echo '<div class="updated" ><p>'.ucfirst($tab).' Options updated.</p></div>';

				?>
				<div id="tab-content">
					<form method="post" action="<?php admin_url( 'edit.php?post_type=track&page=fap-options' ); ?>">
						<?php

						wp_nonce_field( "fap-options-page" );

						if ( $pagenow == 'edit.php' && $_GET['page'] == 'fap-options' ) {

							//include corresponding options page
							include_once(dirname(__FILE__)  .'/admin/'.$tab.'.php');

						}

						if( in_array( $tab, array('general', 'audioplayer')) ):
						?>
						<p class="description"><?php _e('* HTML tags supported!', 'radykal'); ?></p>
						<br />
		                <p class="description"><?php _e('Always save before switching to another tab!', 'radykal'); ?></p>
						<p style="clear: both;">
						<input type="submit" name="save_fap_options" class="button-primary" value="<?php _e('Save Changes', 'radykal'); ?>" <?php disabled( !current_user_can('manage_options') ); ?> />
						<input type="submit" name="reset_fap_options" class="button-secondary" value="<?php _e('Reset Options', 'radykal'); ?>" <?php disabled( !current_user_can('manage_options') ); ?> />
						</p>
						<?php endif; ?>
					</form>
				</div>
			</div>
			<?php

		}

		public function options_admin_tabs( $current = 'homepage' ) {

		    $tabs = array(
		    	'general' => __( 'General', 'radykal' ) ,
		    	'audioplayer' => __( 'Audio Player', 'radykal' ) ,
		    	'shortcode-builder' => __( 'Shortcode Builder', 'radykal' )
		    );

		    echo '<div id="icon-themes" class="icon32"><br></div>';
		    echo '<h2 class="nav-tab-wrapper">';
		    foreach( $tabs as $tab => $name ){
		        $class = ( $tab == $current ) ? ' nav-tab-active' : '';
		        echo "<a class='nav-tab$class' href='?post_type=track&page=fap-options&tab=$tab'>$name</a>";

		    }
		    echo '</h2>';

		}

		public function load_options_page() {

			if ( isset($_POST["save_fap_options"]) || isset($_POST["reset_fap_options"]) ) {
				check_admin_referer( "fap-options-page" );
				$this->save_options();
				$url_parameters = isset($_GET['tab'])? 'updated=true&tab='.$_GET['tab'] : 'updated=true';
				wp_redirect(admin_url('edit.php?post_type=track&page=fap-options&'.$url_parameters));
				exit;
			}

		}

		public function save_options() {

			global $pagenow;
			if ( $pagenow == 'edit.php' && $_GET['page'] == 'fap-options' ){

				if ( isset ( $_GET['tab'] ) )
			        $tab = $_GET['tab'];
			    else
			        $tab = 'general';

			    $tab_options = array();
			    if( isset($_POST["reset_fap_options"]) ) {

			    	switch( $tab ){
				        case 'general' :
				        	$tab_options = self::get_default_general_options();
						break;
				        case 'audioplayer' :
				        	$tab_options = self::get_default_audio_player_options();
						break;
				    }

			    }
			    else if( isset($_POST["save_fap_options"]) ) {
			    	if($tab == 'general') {
				    	foreach(self::get_default_general_options() as $key => $value) {
							$tab_options[$key] = isset( $_POST[$key] ) ? $_POST[$key] : 0;
			        	}
			    	}
			    	else if($tab == 'audioplayer') {
				    	foreach(self::get_default_audio_player_options() as $key => $value) {
							$tab_options[$key] = isset( $_POST[$key] ) ? $_POST[$key] : 0;
			        	}
			    	}

			    }

			}

			//update options associated to the selected tab
			$options = get_option( "fap_options" );
			$options[$tab] = $tab_options;
			update_option( 'fap_options', $options );

		}

		//add meta box in the "Add New Track" page
		public function add_meta_boxes() {

			wp_enqueue_script('fap-admin-new-track', plugins_url('/admin/js/new-track.js', __FILE__));

			add_meta_box('fap-meta-box', __('Track URL & Referral Link', 'radykal'), array( &$this, 'create_meta_box'), 'track', 'normal', 'high');

		}

		//HTML meta box for the "Add New Track" page
		public function create_meta_box() {

			global $post;
			$custom_fields = get_post_custom($post->ID);

			?>

			<label for="fap_track_url"></label><?php _e('<strong>Required</strong> - Set here the URL of the MP3 or the Soundcloud resource:', 'radykal') ?></label>
			<input type="text" name="fap_track_url" value="<?php echo $custom_fields["fap_track_url"][0]; ?>" class="widefat" style="margin-bottom: 5px;" />
			<input type="button" id="fap-add-track" class="button-secondary" value="<?php _e('Add from media library', 'radykal'); ?>" />
			<br /><br />

			<label  for="fap_referral_link"></label><?php _e('<strong>Optional</strong> - Set here the referral link that should be shared on facebook and twitter:', 'radykal') ?></label>
			<input type="text" name="fap_referral_link" value="<?php echo $custom_fields["fap_referral_link"][0]; ?>" class="widefat" />

			<?php
		}

		public function update_custom_meta_fields()	{

			//disable autosave,so custom fields will not be empty
			if ( defined('DOING_AUTOSAVE') && DOING_AUTOSAVE )
		        return $post_id;

			global $post;

			if(isset($_POST["fap_track_url"])) {
				update_post_meta($post->ID, "fap_track_url", trim($_POST["fap_track_url"]));
				update_post_meta($post->ID, "fap_referral_link", trim($_POST["fap_referral_link"]));
				update_post_meta($post->ID, "fap_track_shortcode", '[fap_track id="'.$post->ID.'" layout="list" enqueue="no" auto_enqueue="no"]');
			}

		}

		//create custom column shortcode
		public function add_custom_columns( $defaults ) {

			unset($defaults['date']);
		    $defaults['shortcode'] = __('Shortcode', 'radykal');
			$defaults['date'] = __('Date', 'radykal');
		    return $defaults;

		}

		//add associated data to column
		public function posts_custom_column( $column_name, $id ) {

			global $typenow;
		    if ( $typenow=='track' ) {
		        echo get_post_meta( $id, 'fap_track_shortcode', true );
		    }

		}

		//add filter dropdown with playlists
		public function playlist_filter_list() {

			$screen = get_current_screen();
		    global $wp_query;
		    if ( $screen->post_type == 'track' ) {
		        wp_dropdown_categories( array(
		            'show_option_all' => 'Show All Playlists',
		            'taxonomy' => 'dt_playlist',
		            'name' => 'dt_playlist',
		            'orderby' => 'name',
		            'selected' => ( isset( $wp_query->query['dt_playlist'] ) ? $wp_query->query['dt_playlist'] : '' ),
		            'hierarchical' => false,
		            'depth' => 3,
		            'show_count' => false,
		            'hide_empty' => true,
		        ) );
		    }

		}

		//filter tracks by playlist
		public function perform_filtering( $query ) {

			global $pagenow;
		    $qv = &$query->query_vars;
		    if ( $pagenow=='edit.php' && isset($qv['dt_playlist']) && is_numeric( $qv['dt_playlist'] ) && $qv['dt_playlist'] != 0 ) {
		        $term = get_term_by( 'id', $qv['dt_playlist'], 'dt_playlist' );
		        $qv['dt_playlist'] = $term->slug;
		    }

		}

		private function get_mp3_files() {

			require(dirname(__FILE__).'/getid3/getid3.php');
			$files = scandir($this->mp3_dir);
			$mp3_files = array();

			if( sizeof($files) ) {
				foreach($files as $file ) {

					$mp3_file = array();
					$filepath = $this->mp3_dir . $file;
					$fileurl = $this->mp3_dir_url . $file;

					$getID3 = new getID3;
					$ThisFileInfo = $getID3->analyze($filepath);
					getid3_lib::CopyTagsToComments($ThisFileInfo);

					if( !isset($ThisFileInfo['error']) ) {
						$tags = @$ThisFileInfo['tags'];

						$title = '';
						if(@$tags['id3v2']['artist'][0]) {
							$title = @$tags['id3v2']['artist'][0] . ' - ';
						}
						$title .= @$tags['id3v2']['title'][0];
						$mp3_file['path'] = $filepath;
						$mp3_file['url'] = $fileurl;
						$mp3_file['title'] = $title;
						$mp3_file['meta'] = @$tags['id3v2']['genre'][0];
						$mp3_file['cover'] = isset($getID3->info['id3v2']['PIC'][0]['data']) || isset($getID3->info['id3v2']['APIC'][0]['data']) ? plugins_url('/inc/cover.php?mp3_path='.$filepath.'', __FILE__) : null;

						array_push($mp3_files, $mp3_file);
					}
				}
			}

			return $mp3_files;
		}

		public static function get_default_general_options() {

			return array(
				'player_visibility' => 'all',
				'play_css_class' => 'fap-play-button',
				'enqueue_css_class' => 'fap-enqueue-button',
				'referral_css_class' => 'fap-referral-button',
				'play_button_text' => '<span class="fap-icon-play"></span>Play',
				'pause_button_text' => '<span class="fap-icon-pause"></span>Pause',
				'enqueue_button_text' => '<span class="fap-icon-playlist-add"></span>Enqueue',
				'referral_button_text' => '<span class="fap-icon-link"></span>Buy',
				'login_text' => 'Log in to download',
				'login_to_download' => 0,
				'list_image_width' => 100,
				'list_image_height' => 100,
				'grid_image_width' => 200,
				'grid_image_height' => 200,
				'base64' => 0,
				'public_posts' => 0,
				'souncloud_sdk' => 1,
				'exclude_from_search' => 0
			);

		}

		public static function get_default_audio_player_options() {

			return array(
				'default_playlist' => 'none',
				'wrapper_position' => 'bottom',
				'main_position' => 'center',
				'wrapper_color' => '#f0f0f0',
				'main_color' => '#3c3c3c',
				'fill_color' => '#e3e3e3',
				'meta_color' => '#666666',
				'stroke_color' => '#e0e0e0',
				'wrapper_height' => 80,
				'playlist_height' => 200,
				'facebook_text' => 'Share on Facebook',
				'twitter_text' => 'Share on Twitter',
				'download_text' => 'Download',
				'opened' => 1,
				'volume' => 1,
				'playlist' => 1,
				'autoPlay' => 0,
				'autoLoad' => 1,
				'playNextWhenFinished' => 1,
				'keyboard' => 1,
				'socials' => 1,
				'auto_popup' => 0,
				'randomize' => 0,
				'shuffle' => 1,
				'sortable' => 0,
				'hide_on_mobile' => 0,
				'loop_playlist' => 1,
				'store_playlist' => 0,
				'layout' => 'fullwidth',
				'keep_closed_once_closed' => 0,
				'animate_page_on_player_top' => 0,
				'open_player_on_track_play' => 0,
				'popup' => 1,
				'open_label' => '+',
				'close_label' => '&times;',
				'default_volume' => 1,
				'playlist_order' => 'asc',
				'loading_text' => 'Loading Playlist',
				'popup_title' => 'Fullwidth Audio Player',
				'popup_blocker_text' => 'Pop-Up Music Player can not be opened. Your browser is blocking Pop-Ups. Please allow Pop-Ups for this site to use the Music Player.',
				'html5_audio' => 0
			);

		}

	}
}


//init Fullwidth Audio Player
new FullwidthAudioPlayer();

?>
