<!-- Shortcode Builder -->
<table class="widefat option-table fap-options-table" cellspacing="0" id="fap-shortcode-opts">

	<tbody class="fap-visible">
		<tr valign="top" class="alternate">
			<th scope="row"><strong><?php _e('Shortcode', 'radykal'); ?></strong></th>
			<td>
				<select id="fap-shortcode">
					<option value="fap_playlist" selected="selected"><?php _e('Add Playlist', 'radykal'); ?></option>
					<option value="fap_track"><?php _e('Single track from URL', 'radykal'); ?></option>
					<option value="fap_default_playlist"><?php _e('Default playlist', 'radykal'); ?></option>
					<option value="fap"><?php _e('Add Player', 'radykal'); ?></option>
					<option value="fap_clear_button"><?php _e('Add Clear Button', 'radykal'); ?></option>
					<option value="fap_popup_button"><?php _e('Add Popup Button', 'radykal'); ?></option>
				</select>
			</td>
		</tr>
	</tbody>

	<!-- [fap_playlist fap_default_playlist] -->
	<tbody class="fap_playlist fap_default_playlist">
		<tr valign="top">
			<th scope="row"><?php _e('Playlist', 'radykal'); ?></th>
			<td>
				<select id="fap-playlists">
					<ul>
	      			<?php
	      			$playlists = get_terms('dt_playlist');
					if ( count($playlists) > 0 ){
					    foreach ( $playlists as $playlist ) {
					    	echo '<option value="'.$playlist->term_id.'">' . $playlist->name . '</option>';
					    }
					}
	      			?>
					</ul>
	      		</select>
			</td>
		</tr>
		<tr valign="top" class="alternate hidden-fap_default_playlist">
			<th scope="row"><?php _e('Playlist Button', 'radykal'); ?></th>
			<td>
				<input type="text" id="fap_playlist_button" value="" class="widefat" />
				<span class="checkbox-label"><?php _e('Set a text for the playlist play button. If you do not want this button, just leave it empty:', 'radykal'); ?></span>
			</td>
		</tr>
		<tr valign="top" class="hidden-fap_default_playlist">
			<th scope="row"><?php _e('Center Playlist', 'radykal'); ?></th>
			<td>
				<input type="checkbox" id="fap-center-playlist" value="1" />
				<span class="checkbox-label"><?php _e('Center playlist in page.', 'radykal'); ?></span>
			</td>
		</tr>
		<tr valign="top" class="alternate hidden-fap_default_playlist">
			<th scope="row"><?php _e('Clear Playlist', 'radykal'); ?></th>
			<td>
				<input type="checkbox" id="fap-clear-playlist" value="1" />
				<span class="checkbox-label"><?php _e('Clear playing playlist when playlist button is clicked.', 'radykal'); ?></span>
			</td>
		</tr>
	</tbody>

	<!-- [fap_track] -->
	<tbody class="fap_track">
		<tr valign="top" class="">
			<th scope="row"><?php _e('Soundcloud, Official.fm or MP3 URL', 'radykal'); ?></th>
			<td>
				<input type="text" id="fap-single-url" class="widefat" />
			</td>
		</tr>
		<tr valign="top" class=" alternate">
			<th scope="row"><?php _e('Title', 'radykal'); ?></th>
			<td>
				<input type="text" id="fap-single-title" class="widefat" placeholder="<?php _e( 'Optional', 'radykal'); ?>" />
			</td>
		</tr>
		<tr valign="top" class="">
			<th scope="row"><?php _e('Share URL', 'radykal'); ?></th>
			<td>
				<input type="text" id="fap-single-share" class="widefat" placeholder="<?php _e( 'Optional', 'radykal'); ?>" />
			</td>
		</tr>
		<tr valign="top" class="alternate">
			<th scope="row"><?php _e('Cover URL', 'radykal'); ?></th>
			<td>
				<input type="text" id="fap-single-cover" class="widefat" placeholder="<?php _e( 'Optional', 'radykal'); ?>" />
			</td>
		</tr>
		<tr valign="top">
			<th scope="row"><?php _e('Meta Text', 'radykal'); ?></th>
			<td>
				<input type="text" id="fap-single-meta" class="widefat" placeholder="<?php _e( 'Optional', 'radykal'); ?>" />
			</td>
		</tr>
	</tbody>

	<!-- [fap_track fap_playlist] -->
	<tbody class="fap_track fap_playlist">
		<tr valign="top" class="alternate">
			<th scope="row"><?php _e('Layout', 'radykal'); ?></th>
			<td>
				<select id="fap-layout">
		      		<option value="list"><?php _e('List - Image Left/Text Right', 'radykal'); ?></option>
			  		<option value="list-icon"><?php _e('List Icon - Image Left/Text Right/Icons', 'radykal'); ?></option>
		      		<option value="grid"><?php _e('Grid - Image Top/Text Bottom', 'radykal'); ?></option>
		      		<option value="grid-icon"><?php _e('Grid Icon - Image Left/Text Right/Icons', 'radykal'); ?></option>
		      		<option value="interactive-image"><?php _e('Grid - Interactive Image', 'radykal'); ?></option>
		      		<option value="simple"><?php _e('Simple - Just Anchors', 'radykal'); ?></option>
		      		<option value="button"><?php _e('Button', 'radykal'); ?></option>
		      		<option value="hidden"><?php _e('Hidden - Invisible anchors', 'radykal'); ?></option>
	      		</select>
			</td>
		</tr>
		<tr valign="top">
			<th scope="row"><?php _e('Auto-Enqueue', 'radykal'); ?></th>
			<td>
				<input type="checkbox" id="fap-auto-enqueue" value="1" />
				<span class="checkbox-label"><?php _e('Enqueue into the player when player is ready.', 'radykal'); ?></span>
			</td>
		</tr>
		<tr valign="top" class="alternate fap-hide-layout-hidden">
			<th scope="row"><?php _e('Enqueue Button', 'radykal'); ?></th>
			<td>
				<input type="checkbox" id="fap-enqueue-button" value="1" />
				<span class="checkbox-label"><?php _e('Enable an Enqueue button.', 'radykal'); ?></span>
			</td>
		</tr>

	</tbody>

	<!-- [fap] -->
	<tbody class="fap">
		<tr valign="top">
			<th scope="row"><?php _e('Replace shortcode with player', 'radykal'); ?></th>
			<td>
				<input type="checkbox" id="fap-add-here" value="1" />
				<span class="checkbox-label"><?php _e('The player will be added in the shortcode position.', 'radykal'); ?></span>
			</td>
		</tr>
	</tbody>

	<!-- [fap_popup_button] -->
	<tbody class="fap_popup_button">
		<tr valign="top">
			<th scope="row"><?php _e('Label', 'radykal'); ?></th>
			<td>
				<input type="text" id="fap-popup-button-label" class="widefat" />
			</td>
		</tr>
		<tr valign="top">
			<th scope="row"><?php _e('CSS Classes', 'radykal'); ?></th>
			<td>
				<input type="text" id="fap-popup-button-css-classes" class="widefat" />
			</td>
		</tr>
	</tbody>

	<!-- [fap_clear_button] -->
	<tbody class="fap_clear_button">
		<tr valign="top">
			<th scope="row"><?php _e('Label', 'radykal'); ?></th>
			<td>
				<input type="text" id="fap-clear-button-label" class="widefat" />
			</td>
		</tr>
		<tr valign="top">
			<th scope="row"><?php _e('CSS Classes', 'radykal'); ?></th>
			<td>
				<input type="text" id="fap-clear-button-css-classes" class="widefat" />
			</td>
		</tr>
	</tbody>
</table>

<p>
	<button id="fap-form-submit" class="button-primary"><?php _e('Create Shortcode', 'radykal') ?></button>
	<p class="description"><?php _e('Copy Shortcode', 'radykal') ?></p>
	<textarea readonly="readyonly" class="widefat" style="height: 85px;" id="fap-copy-shortcode"></textarea>
</p>
<script type="text/javascript">

jQuery(document).ready(function($) {

	var $shortcodeTable = $('#fap-shortcode-opts'),
		shortcode = 'fap_playlist'

		$formSubmitBtn = $('#fap-form-submit'),
		$copyShortcode = $('#fap-copy-shortcode');

	$('#fap-shortcode').change(function() {

		var $this = $(this);

		$shortcodeTable.children('tbody').hide();
		$shortcodeTable.children('tbody.'+this.value).show();


		$shortcodeTable.find('tbody tr[class^="hidden-"]').show()
		$shortcodeTable.find('tbody tr.hidden-'+this.value).hide();

		shortcode = this.value;

		$copyShortcode.val('');

	}).change();

	$('#fap-layout').change(function() {

		$('.fap-hide-layout-hidden').toggle(this.value !== 'hidden');

	}).change();

	$formSubmitBtn.click(function(evt) {

		evt.preventDefault();

		var shortocdeStr = '['+shortcode;

		if(shortcode == 'fap_playlist' || shortcode == 'fap_default_playlist') {

			shortocdeStr += ' id='+$('#fap-playlists').val();

			if(shortcode == 'fap_playlist') {
				shortocdeStr += ' center='+($('#fap_center_playlist').is(':checked') ? 'yes' : 'no');
				shortocdeStr += ' playlist_button="'+$('#fap_playlist_button').val()+'"';
				shortocdeStr += ' layout="'+$('#fap-layout').val()+'"';
				shortocdeStr += ' enqueue='+($('#fap-enqueue-button').is(':checked') ? 'yes' : 'no');
				shortocdeStr += ' auto_enqueue='+($('#fap-auto-enqueue').is(':checked') ? 'yes' : 'no');
				shortocdeStr += ' clear='+($('#fap_playlist_clear').is(':checked') ? 'yes' : 'no');
			}

		}
		else if(shortcode == 'fap_track') {

			shortocdeStr += ' url="'+$('#fap-single-url').val()+'"';
			shortocdeStr += ' title="'+$('#fap-single-title').val()+'"';
			shortocdeStr += ' share="'+$('#fap-single-share').val()+'"';
			shortocdeStr += ' cover="'+$('#fap-single-cover').val()+'"';
			shortocdeStr += ' meta="'+$('#fap-single-meta').val()+'"';
			shortocdeStr += ' layout="'+$('#fap-layout').val()+'"';
			shortocdeStr += ' enqueue='+($('#fap-enqueue-button').is(':checked') ? 'yes' : 'no');
			shortocdeStr += ' auto_enqueue='+($('#fap-auto-enqueue').is(':checked') ? 'yes' : 'no');

		}
		else if(shortcode == 'fap_clear_button') {

			shortocdeStr += ' label="'+$('#fap-clear-button-label').val()+'"';
			shortocdeStr += ' css_class="'+$('#fap-clear-button-css-classes').val()+'"';

		}
		else if(shortcode == 'fap_popup_button') {

			shortocdeStr += ' label="'+$('#fap-popup-button-label').val()+'"';
			shortocdeStr += ' css_class="'+$('#fap-popup-button-css-classes').val()+'"';

		}
		else if(shortcode == 'fap') {

			shortocdeStr += ' add_here='+($('#fap-add-here').is(':checked') ? 'yes' : 'no');

		}

		shortocdeStr += ']';
		$copyShortcode.val(shortocdeStr);

	});

	$copyShortcode.on('click', function () {
	   $copyShortcode.select();
	});

});

</script>