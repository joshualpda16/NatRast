<?php

if( !class_exists('FAP_Admin_MP3_Directory') ) {

	class FAP_Admin_MP3_Directory {

		public function __construct() {

			add_action( 'wp_ajax_settrack', array( &$this, 'set_mp3_track' ) );
			add_action( 'wp_ajax_deletetrack', array( &$this, 'delete_mp3_track' ) );
			add_action( 'wp_ajax_updatesort', array( &$this, 'update_mp3_sort' ) );

		}

		public function set_mp3_track() {

			header( "Content-Type: application/json" );

			//set
			if(intval($_POST['id']) == -1) {
				$mp3_track = array(
					'post_title' => $_POST['title'],
					'post_content' => $_POST['meta'],
					'post_type' => 'track',
					'post_status' => 'publish'
				);

				$id = wp_insert_post($mp3_track);
				if($id) {
					$playlist_id = array(intval($_POST['playlistId']));
					wp_set_post_terms( $id, $playlist_id, 'dt_playlist' );
					add_post_meta( $id, 'fap_track_url', $_POST['url'] );
					add_post_meta( $id, 'fap_track_path', $_POST['path'] );
					add_post_meta( $id, "fap_track_shortcode", '[fap_track id="'.$id.'" layout="list" enqueue="no" auto_enqueue="no"]');
					if( !empty($_POST['cover']) )
						add_post_meta( $id, 'fap_track_cover', $_POST['cover'] );
				}
				echo json_encode($id);
			}
			//update
			else {

				$id = intval($_POST['id']);
				$track_post = array();
				$track_post['ID'] = $id;
				if($update = wp_update_post( $track_post ) ) {
					$playlist_id = array(intval($_POST['playlistId']));
					$update = wp_set_post_terms( $id, $playlist_id, 'dt_playlist' );
				}

				echo json_encode($update);
			}

			exit;
		}

		public function delete_mp3_track() {

			header( "Content-Type: application/json" );

			//delete
			$id = intval( $_POST['id'] );
			$delete = wp_delete_post($id, true);

			if( $delete ) {
				delete_post_meta($id, 'fap_track_url');
				delete_post_meta($id, 'fap_track_path');
				delete_post_meta($id, 'fap_track_cover');
				delete_post_meta($id, 'fap_track_shortcode');
			}

			echo json_encode($delete);

			exit;
		}

		public function update_mp3_sort() {

			header( "Content-Type: application/json" );

			//delete
			$ids =	$_POST['ids'];

			for($i=0; $i < sizeof($ids); $i++) {
				$track_post = array();
				$track_post['ID'] = $ids[$i];
				$track_post['menu_order'] = $i;
				wp_update_post( $track_post );
			}

			echo json_encode(1);

			exit;
		}

	}

}

new FAP_Admin_MP3_Directory();

?>