=== Fullwidth Audio Player ===
Contributors: radykal alias Rafael Dery


== Installation ==

Simply drop the fullwdith-audio-player folder into your wp-content/plugins folder.


== Information ==

Hi,

first of all thanks for purchasing my product. I hope you gonna like it and you have no problems to set it up for your needs. You find the documentation online:

http://radykal.de/wordpress-plugins/fullwidth-audio-player/getting-started/


If you still have problems after reading the documentation, please use my support forum. First use the search for finding an answer on your question/problem. If you do not find any related topics, please open a new thread.

http://support.radykal.de/


Thanks!

Rafael
