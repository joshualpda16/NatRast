<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

if( !class_exists('FAP_Install') ) {

	class FAP_Install {

		public function __construct() {

			register_activation_hook( FAP_PLUGIN_ROOT_PHP, array( &$this, 'activate_fap_plugin' ) );

			add_action( 'plugins_loaded', array( &$this,'check_version' ) );
		}

		public function activate_fap_plugin() {

			global $wpdb;

			if ( is_multisite() ) {
	    		if (isset($_GET['networkwide']) && ($_GET['networkwide'] == 1)) {
	                $current_blog = $wpdb->blogid;
	    			// Get all blog ids
	    			$blogids = $wpdb->get_col($wpdb->prepare("SELECT blog_id FROM $wpdb->blogs"));
	    			foreach ($blogids as $blog_id) {
	    				switch_to_blog($blog_id);
	    				$this->install();
	    			}
	    			switch_to_blog($current_blog);
	    			return;
	    		}
	    	}

			$this->install();

		}

		private function install() {

			if( !get_option('fap_options') ) {

		        $default_fap_options = array(
		        	'general' => FullwidthAudioPlayer::get_default_general_options(),
		        	'audioplayer' => FullwidthAudioPlayer::get_default_audio_player_options()
		        );

				add_option('fap_options', $default_fap_options );
			}

		}

		public function check_version() {

			$current_version = get_option(FullwidthAudioPlayer::VERSION_FIELD_NAME);

			//to 1.1.31
			if($current_version == '1.1.3') {
				update_option(FullwidthAudioPlayer::VERSION_FIELD_NAME, '1.1.31');
			}

			//to 1.1.32
			if($current_version == '1.1.31') {
				update_option(FullwidthAudioPlayer::VERSION_FIELD_NAME, '1.1.32');
			}

			//to 1.1.32
			if($current_version == '1.1.32') {
				$options = get_option( 'fap_options');
				$options['general']['souncloud_sdk'] = 1;
				$options['general']['exclude_from_search'] = 0;
				$options['general']['pause_button_text'] = 'Pause';
				$options['general']['enqueue_css_class'] = 'fap-enqueue-button';
				update_option( 'fap_options', $options );
				update_option(FullwidthAudioPlayer::VERSION_FIELD_NAME, '1.1.5');
			}

			//to 1.1.51
			if($current_version == '1.1.5') {
				update_option(FullwidthAudioPlayer::VERSION_FIELD_NAME, '1.1.51');
			}

			//to 1.1.6
			if($current_version == '1.1.6') {
				update_option(FullwidthAudioPlayer::VERSION_FIELD_NAME, '1.1.6');
			}

			//to 1.1.6
			if($current_version == '2.0.0') {

				$options = get_option( 'fap_options');
				$options['audioplayer']['default_volume'] = 1;
				$options['audioplayer']['playlist_order'] = 'asc';
				$options['audioplayer']['loading_text'] = 'Loading Playlist';
				$options['audioplayer']['popup_title'] = 'Fullwidth Audio Player';
				$options['audioplayer']['popup_blocker_text'] = 'Pop-Up Music Player can not be opened. Your browser is blocking Pop-Ups. Please allow Pop-Ups for this site to use the Music Player.';
				$options['audioplayer']['html5_audio'] = 0;

				update_option(FullwidthAudioPlayer::VERSION_FIELD_NAME, '2.0.0');

			}

		}

	}

}

new FAP_Install();

?>