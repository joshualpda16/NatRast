<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

if( !class_exists('FAP_Frontend') ) {

	class FAP_Frontend {

		private $default_playlist = false;
		private $custom_player_pos = false;

		public function __construct() {

			add_action( 'wp_enqueue_scripts', array( &$this,'add_scripts_styles' ) );
			add_action( 'wp_footer', array( &$this,'include_fap_frontend' ) );

			add_shortcode( 'fap_default_playlist', array( &$this, 'change_default_playlist' ) );
			add_shortcode( 'fap_track', array( &$this, 'create_single_track' ) );
			add_shortcode( 'fap_playlist', array( &$this, 'create_playlist' ) );
			add_shortcode( 'fap', array( &$this, 'add_player' ) );
			add_shortcode( 'fap_popup_button', array( &$this, 'add_popup_button' ) );
			add_shortcode( 'fap_clear_button', array( &$this, 'add_clear_button' ) );

		}

		//include all styles and scripts for the player
		public function add_scripts_styles() {

			$fap_css = '/css/jquery.fullwidthAudioPlayer.min.css';
			$fap_js = '/js/jquery.fullwidthAudioPlayer.min.js';
			if( FullwidthAudioPlayer::DEBUG ) {

				$fap_css = '/css/jquery.fullwidthAudioPlayer.css';
				$fap_js = '/js/jquery.fullwidthAudioPlayer.js';

			}

			wp_enqueue_style( 'fullwidth-audio-player-tracks', plugins_url('/css/fullwidthAudioPlayer-tracks.css', FAP_PLUGIN_ROOT_PHP), false, FullwidthAudioPlayer::VERSION );
			wp_enqueue_style( 'fullwidth-audio-player', plugins_url($fap_css, FAP_PLUGIN_ROOT_PHP) );

			wp_enqueue_script( 'soundcloud-sdk', '//connect.soundcloud.com/sdk/sdk-3.1.2.js' );
			wp_enqueue_script( 'fullwidth-audio-player', plugins_url($fap_js, FAP_PLUGIN_ROOT_PHP), array(
				'jquery',
				'jquery-ui-draggable',
				'jquery-ui-sortable'),
			FullwidthAudioPlayer::VERSION );


		}

		//setup player in frontend
		public function include_fap_frontend() {

			if(is_admin())
				return false;

			$options = get_option('fap_options');
			$general_options = $options['general'];

			global $post;

			if(
				//to all all pages
				$general_options['player_visibility'] == 'all' ||
				//shortcodes found
				($general_options['player_visibility'] == 'shortcodes' && (strpos($post->post_content,'[fap') !== false || strpos($post->post_excerpt,'[fap') !== false) ) ||
				//only frontpage
				($general_options['player_visibility'] == 'frontpage' && is_front_page()) )
			{
				?>
				<!-- HTML starts here -->
				<div id="fullwidthAudioPlayer" style="display: none;">

				<?php

				//get options
				$audio_player_options = $options['audioplayer'];
				$audio_player_options = fap_check_options_availability($audio_player_options);
				$audio_player_options = apply_filters( 'fap_js_audio_player_options', $audio_player_options );
				$wrapper_pos = $this->custom_player_pos ? $this->custom_player_pos : $audio_player_options['wrapper_position'];

				$order = $audio_player_options['playlist_order'] == 'desc' ? 'DESC' : 'ASC';
				$args = array(
					'orderby' => 'menu_order',
					'order' => $order,
					'posts_per_page' => -1,
					'post_type' => 'track',
					'tax_query' => array(
						array(
							'taxonomy' => 'dt_playlist',
							'field' => 'id',
							'terms' => $this->default_playlist ? $this->default_playlist : $audio_player_options['default_playlist']
						)
					)
				);

				$query = new WP_Query( $args );
				//loop starts
				if ($query->have_posts()) : while ($query->have_posts()) : $query->the_post();

				//get custom fields
                $custom_fields = get_post_custom( get_the_ID() );

                //get cover if one is set
                $cover = '';
                if(!empty($custom_fields['fap_track_cover'][0])) {
	                $cover = $custom_fields['fap_track_cover'][0];
                }
                else if( has_post_thumbnail() ) {
                	$image_attributes = wp_get_attachment_image_src ( get_post_thumbnail_id ( get_the_ID() ), 'thumbnail');
                	$cover = $image_attributes[0];
                }

                //get description text
                $content = get_the_content();
                $meta_id = 'fap-meta-'.get_the_ID();
                $target_html = isset( $custom_fields['fap_referral_link'] ) ? 'target="'.$custom_fields['fap_referral_link'][0].'"' : '';
				?>
				<a href="<?php echo fap_int_to_bool($general_options['base64']) ? base64_encode($custom_fields['fap_track_url'][0]) : $custom_fields['fap_track_url'][0]; ?>" title="<?php the_title(); ?>" <?php echo $target_html; ?> rel="<?php echo $cover; ?>" data-meta="#<?php echo $meta_id; ?>"></a>

				<!-- Set description text if track has one -->
				<?php if( !empty($content) ): ?>
				<span id="<?php echo $meta_id; ?>" ><?php the_content(); ?></span>
				<?php endif; ?>

				<?php endwhile; endif; wp_reset_query(); ?>
				</div>
				<!-- HTML ends here -->

				<script type="text/javascript">

					jQuery(document).ready(function() {

						$ = jQuery.noConflict();

						//do not init again
						if(jQuery('body').find('.fap-wrapper').size() > 0) { return false; }

						jQuery('#fullwidthAudioPlayer').fullwidthAudioPlayer({
							opened: <?php echo fap_int_to_bool($audio_player_options['opened']); ?>,
							volume: <?php echo fap_int_to_bool($audio_player_options['volume']); ?>,
							playlist: <?php echo fap_int_to_bool($audio_player_options['playlist']); ?>,
							autoPlay: <?php echo fap_int_to_bool($audio_player_options['autoPlay']); ?>,
							autoLoad:<?php echo fap_int_to_bool($audio_player_options['autoLoad']); ?>,
							playNextWhenFinished: <?php echo fap_int_to_bool($audio_player_options['playNextWhenFinished']); ?>,
							keyboard: <?php echo fap_int_to_bool($audio_player_options['keyboard']); ?>,
							socials: <?php echo fap_int_to_bool($audio_player_options['socials']); ?>,
							wrapperColor: '<?php echo $audio_player_options['wrapper_color']; ?>',
							mainColor: '<?php echo $audio_player_options['main_color']; ?>',
							fillColor: '<?php echo $audio_player_options['fill_color']; ?>',
							metaColor: '<?php echo $audio_player_options['meta_color']; ?>',
							strokeColor: '<?php echo $audio_player_options['stroke_color']; ?>',
							wrapperPosition: window.fapPopupWin ? 'popup' : '<?php echo $wrapper_pos; ?>',
							mainPosition: '<?php echo $audio_player_options['main_position']; ?>',
							height: <?php echo $audio_player_options['wrapper_height']; ?>,
							playlistHeight: <?php echo $audio_player_options['playlist_height']; ?>,
							twitterText: '<?php echo $audio_player_options['twitter_text']; ?>',
							facebookText: '<?php echo $audio_player_options['facebook_text']; ?>',
							downloadText: '<?php echo $audio_player_options['download_text']; ?>',
							popupUrl: '<?php echo plugins_url('popup.html', FAP_PLUGIN_ROOT_PHP);  ?>',
							autoPopup: <?php echo fap_int_to_bool($audio_player_options['auto_popup']); ?>,
							randomize: <?php echo fap_int_to_bool($audio_player_options['randomize']); ?>,
							shuffle:<?php echo fap_int_to_bool($audio_player_options['shuffle']); ?>,
							base64: <?php echo fap_int_to_bool($general_options['base64']); ?>,
							sortable: <?php echo fap_int_to_bool($audio_player_options['sortable']); ?>,
							hideOnMobile: <?php echo fap_int_to_bool($audio_player_options['hide_on_mobile']); ?>,
							loopPlaylist : <?php echo fap_int_to_bool($audio_player_options['loop_playlist']); ?>,
							storePlaylist: <?php echo fap_int_to_bool($audio_player_options['store_playlist']); ?>,
							layout: '<?php echo $audio_player_options['layout']; ?>',
							keepClosedOnceClosed: <?php echo fap_int_to_bool($audio_player_options['keep_closed_once_closed']); ?>,
							animatePageOnPlayerTop: <?php echo fap_int_to_bool($audio_player_options['animate_page_on_player_top']); ?>,
							openPlayerOnTrackPlay: <?php echo fap_int_to_bool($audio_player_options['open_player_on_track_play']); ?>,
							popup: <?php echo fap_int_to_bool($audio_player_options['popup']); ?>,
							openLabel: '<?php echo $audio_player_options['open_label']; ?>',
							closeLabel: '<?php echo $audio_player_options['close_label']; ?>',
							htmlURL: '<?php echo plugins_url('fwap.php', FAP_PLUGIN_ROOT_PHP);  ?>',
							loadingText: '<?php echo $audio_player_options['loading_text']; ?>',
							popupTitle : '<?php echo $audio_player_options['popup_title']; ?>',
							popupBlockerText: '<?php echo $audio_player_options['popup_blocker_text']; ?>',
							howlOptions: {html5: <?php echo fap_int_to_bool($audio_player_options['html5_audio']); ?>},
							debug: false
						});

						jQuery('.fap-popup-player').click(function() {
							jQuery.fullwidthAudioPlayer.popUp();
						});

						jQuery('.fwap-clear-button').on('click', function() {
							jQuery.fullwidthAudioPlayer.clear();
						});

						var playText = '<?php echo fap_decode_to_html($general_options['play_button_text']); ?>',
							pauseText = '<?php echo fap_decode_to_html($general_options['pause_button_text']); ?>',
							playIcon = '<span class="fap-icon-play"></span>',
							pauseIcon = '<span class="fap-icon-pause"></span>',
							currentTrackUrl = null,
							selectedPlayButton = null;

						jQuery('#fullwidthAudioPlayer').on('onFapReady', function(evt) {
							jQuery.fullwidthAudioPlayer.volume(<?php echo $audio_player_options['default_volume']; ?>);
						});

						jQuery('#fullwidthAudioPlayer').on('onFapTrackSelect', function(evt, trackData, playState) {

							if(trackData.duration == null) {
								//mp3,official.fm
								currentTrackUrl = trackData.stream_url;

								if(currentTrackUrl.search('official.fm') != -1) {

									currentTrackUrl = trackData.permalink_url;

								}
							}
							else {
								//soundcloud
								currentTrackUrl = trackData.permalink_url;

							}

							//pre-selected track button to play
							if(selectedPlayButton != null) {
								selectedPlayButton.html(selectedPlayButton.parents('.fap-icons').size() > 0 ? playIcon : playText);
							}
							//search for a play button with the same title
							if( <?php echo fap_int_to_bool($general_options['base64']); ?> ) {
								currentTrackUrl = Base64.encode(currentTrackUrl);
							}
							else {
								currentTrackUrl = currentTrackUrl.replace(/.*?:\/\//g, "").replace(/^www./, "");
							}

							selectedPlayButton = jQuery('.<?php echo $general_options['play_css_class']; ?>[href*="'+currentTrackUrl+'"]');

							if(playState) {
								selectedPlayButton.html(selectedPlayButton.parents('.fap-icons').size() > 0 ? pauseIcon : pauseText);
							}
							else {
								selectedPlayButton.html(selectedPlayButton.parents('.fap-icons').size() > 0 ? playIcon : playText);
							}
						})
						.on('onFapPlay', function() {
							if(selectedPlayButton != null) {
								selectedPlayButton.html(selectedPlayButton.parents('.fap-icons').size() > 0 ? pauseIcon : pauseText);
							}
						})
						.on('onFapPause', function() {
							if(selectedPlayButton != null) {
								selectedPlayButton.html(selectedPlayButton.parents('.fap-icons').size() > 0 ? playIcon : playText);
							}
						});

						var trackWrapperMargin = null;

						jQuery(window).resize(function() {

							jQuery('.fap-center').each(function(i, item) {

								var $item = $(item),
									$trackWrapper = $item.children('div:first'),
									trackWrapperWidth = $trackWrapper.outerWidth(true),
									numOfTracksPerRow = Math.floor($item.parent().width() / trackWrapperWidth);

								if($trackWrapper.length == 0) {
									return;
								}

								if(trackWrapperMargin === null) {
									trackWrapperMargin = parseInt($trackWrapper.css('marginRight'));
								}

								$item.children('div').css('marginRight', trackWrapperMargin)
								.filter(':nth-child('+String(numOfTracksPerRow)+'n)').css('marginRight', 0);

								if(numOfTracksPerRow == 1) {
									$item.width(trackWrapperWidth);
								}
								else {
									$item.width((trackWrapperWidth * numOfTracksPerRow) - trackWrapperMargin);
								}



							});

						}).resize();


					});
				</script>

				<?php
			}

		}

		//shorcode handler for changing the default playlist
		public function change_default_playlist( $atts ) {

			extract( shortcode_atts( array(
				'id' => 0
			), $atts ) );

			$this->default_playlist = $id;

			return '';
		}

		//shorcode handler for adding the player into a page, just return nothing
		public function add_player( $atts ) {

			extract( shortcode_atts( array(
				'add_here' => 'no'
			), $atts ) );

			if( $add_here == 'yes' ) {

				$this->custom_player_pos = '#fap-custom-fap-pos';
				return '<div id="fap-custom-fap-pos"></div>';

			}

			return '';

		}

		//shorcode handler for adding a popup button
		public function add_popup_button( $atts ) {

			extract( shortcode_atts( array(
				'label' => 'Pop up player',
				'css_class' => ''
			), $atts ) );

			return '<span class="fap-popup-player '.$css_class.'">'.$label.'</span>';
		}

		public function add_clear_button( $atts ) {

			extract( shortcode_atts( array(
				'label' => 'Clear',
				'css_class' => ''
			), $atts ) );

			return '<span class="fwap-clear-button '.$css_class.'">'.$label.'</span>';
		}

		//shorcode handler for a single track container
		public function create_single_track( $atts ) {

			extract( shortcode_atts( array(
				'id' => null,
				'url' => null,
				'title' => '',
				'share_link' => '',
				'cover' => '',
				'meta' => '',
				'auto_enqueue' => 'no', //enqueue the tracks when player is ready
				'layout' => 'grid', //grid, list, simple, hidden, button
				'enqueue' => 'no' //enqueue the track on button-click
			), $atts ) );

			if($id) {

				$track_data = $this->get_stored_track_data($id, $layout);
				return $this->get_track_wrapper( $track_data['url'], $track_data['title'], $track_data['cover'], $track_data['meta'], $track_data['share_link'], $layout, $enqueue, $auto_enqueue, $track_data['cover_alt'] );

			}
			else {

				$options = get_option('fap_options');
				$general_options = $options['general'];
				$url = fap_int_to_bool($general_options['base64']) ? base64_encode($url) : $url;
				return $this->get_track_wrapper( $url, $title, $cover, $meta, $share_link, $layout, $enqueue, $auto_enqueue );

			}

		}

		//shortcode handler for a tracklist
		public function create_playlist( $atts ) {

			extract( shortcode_atts( array(
				'id' => 0,
				'layout' => 'grid', //grid,list,simple,hide
				'enqueue' => 'no', //yes,no
				'playlist_button' => '', //empty or custom text for the button
				'auto_enqueue' => 'no',
				'center' => 'no',
				'clear' => 'no',
				'order' => 'asc'
			), $atts ) );

			$order = $order == 'asc' ? 'ASC' : 'DESC';
			$args = array(
				'orderby' => 'menu_order',
				'order' => $order,
				'posts_per_page' => -1,
				'post_type' => 'track',
				'tax_query' => array(
					array(
						'taxonomy' => 'dt_playlist',
						'field' => 'id',
						'terms' => $id
					)
				)
			);

			$options = get_option('fap_options');
			$general_options = $options['general'];

			$query = new WP_Query( $args );
			$output = '';

			if($playlist_button != '')
				$output .= '<span class="fap-add-playlist '.$general_options['play_css_class'].'" data-playlist="'.$id.'" data-enqueue="'.$enqueue.'" data-clear="'.$clear.'">'.fap_decode_to_html( $playlist_button ).'</span>';

			$center_html = '';
			if($center == 'yes' && $layout != 'list')
				$center_html = 'fap-center';

			$output .= '<div class="fap-in-page-playlist-'.$layout.' '.$center_html.' fap-clearfix" data-playlist="'.$id.'">';

			//loop starts
			if ( $query->have_posts() ) {
				while ( $query->have_posts() ) {
					$query->the_post();
					$track_data = $this->get_stored_track_data(get_the_ID(), $layout);
					$output .= $this->get_track_wrapper( $track_data['url'], $track_data['title'], $track_data['cover'], $track_data['meta'], $track_data['share_link'], $layout, $enqueue, $auto_enqueue, $track_data['cover_alt'] );
				}
			}

			wp_reset_query();

			$output .= '</div>';
			//loop ends

			return $output;

		}

		public function get_stored_track_data( $post_id, $layout ) {

			$track_data = array();

			$options = get_option('fap_options');
			$general_options = $options['general'];

			$track_post = get_post( $post_id );
			$custom_fields = get_post_custom( $post_id );

			//store url
			$track_data['url'] = fap_int_to_bool($general_options['base64']) ? base64_encode($custom_fields['fap_track_url'][0]) : $custom_fields['fap_track_url'][0];

			//store title
			$track_data['title'] = str_replace('-', '&ndash;', $track_post->post_title);

			//store cover
	        $track_data['cover'] = null;
	        $track_data['cover_alt'] = '';
	        if(!empty($custom_fields['fap_track_cover'][0])) {
		        $track_data['cover'] = $custom_fields['fap_track_cover'][0];
            }
            else if( has_post_thumbnail( $post_id ) ) {
            	$image_attributes = wp_get_attachment_image_src ( get_post_thumbnail_id ( $post_id ), ($layout == 'list' ? 'fap-list-thumbnail' : 'fap-grid-thumbnail'));
            	$track_data['cover'] = $image_attributes[0];
            	$track_data['cover_alt'] = get_the_title( get_post_thumbnail_id ( $post_id ) );
            }

            //store meta
            $track_data['meta'] = empty( $track_post->post_content ) ? '' : $track_post->post_content;

            //store share link
            $track_data['share_link'] = empty( $custom_fields['fap_referral_link'][0] ) ? '' : $custom_fields['fap_referral_link'][0];

            return $track_data;
		}

		//returns a track container
		public function get_track_wrapper( $url, $title, $cover, $meta, $share_link, $layout, $enqueue, $auto_enqueue, $cover_alt='' ) {

			if(empty($url))
				return;

			$options = get_option('fap_options');
			$general_options = $options['general'];

			$sanitized_title = sanitize_title($title);
			$unique_id = uniqid();
			$unique_id_meta = '#fap-meta-'.$unique_id;
			$play_button_html = fap_decode_to_html($general_options['play_button_text']);
			$enqueue_button_html = fap_decode_to_html( $general_options['enqueue_button_text'] );

			$meta_html = empty( $meta ) ? '' : '<span id="fap-meta-'.$unique_id.'" style="display: none;">'.do_shortcode($meta).'</span>';

			$referral_link_html = '';

			if( !empty( $share_link ) ) {

				if( !is_user_logged_in() && $general_options['login_to_download'] ) {

					global $wp;
					$current_url = home_url(add_query_arg(array(),$wp->request));

					$referral_button_text = ($layout == 'list-icon' || $layout == 'grid-icon') ? '<span class="fap-icon-link"></span>' : fap_decode_to_html( $general_options['login_text'] );
					$referral_link_html = '<a href="'.wp_login_url( $current_url ).'" title="'.$general_options['login_text'].'" class="'.$general_options['referral_css_class'].'" title="'.strip_tags( $general_options['login_text'] ).'">'.$referral_button_text.'</a>';

				}
				else {

					$referral_button_text = ($layout == 'list-icon' || $layout == 'grid-icon') ? '<span class="fap-icon-link"></span>' : fap_decode_to_html( $general_options['referral_button_text'] );
					$referral_link_html = '<a href="'.$share_link.'" target="_blank" class="'.$general_options['referral_css_class'].'" title="'.strip_tags( $general_options['referral_button_text'] ).'">'.$referral_button_text.'</a>';

				}
			}

			if($layout == 'simple' || $layout == 'hidden' || $layout == 'button') {

				$elem_title = $title;
				$class = 'fap-track-'.$layout;
				$tooltip = '';
				if($layout == 'button') { //button
					$elem_title = $enqueue == 'yes' ? $enqueue_button_html : $play_button_html;
					$class .= $enqueue == 'yes' ? ' '.$general_options['enqueue_css_class'] : ' '.$general_options['play_css_class'];
					$tooltip = 'title="'.esc_attr($title).'"';
				}
				return '<a href="'.$url.'" title="'.htmlspecialchars($title).'" rel="'.$cover.'" target="'.$share_link.'" data-meta="'.$unique_id_meta.'" class="fap-single-track '.$class.'" data-enqueue="'.$enqueue.'" data-autoenqueue="'.$auto_enqueue.'" '.$tooltip.'>'.$elem_title.'</a>'.$meta_html.'';


			}
			else {

				$thumbnail_dom = '';
				$item_width = $layout == 'grid' || $layout == 'interactive-image' ? $general_options['grid_image_width'] : $general_options['list_image_width'];
				$item_height = $layout == 'grid' || $layout == 'interactive-image' ? $general_options['grid_image_height'] : $general_options['list_image_height'];

				$thumbnail_html = '';
				if ( !empty($cover) ) {
					$thumbnail_html = '<img src="'.$cover.'" width='.$item_width.' height='.$item_height.' alt="'.$cover_alt.'" />';
				}

				$enqueue_html = '';
				$enqueue_button_html = ($layout == 'list-icon' || $layout == 'grid-icon') ? '<span class="fap-icon-playlist-add"></span>' : $enqueue_button_html;
				if($enqueue == 'yes') {
					$enqueue_html = '<a href="'.$url.'" title="'.htmlspecialchars($title) .'" rel="'.$cover.'" target="'.$share_link.'" data-meta="'.$unique_id_meta.'" class="'.$general_options['enqueue_css_class'].' fap-single-track" data-enqueue="yes">'.$enqueue_button_html.'</a>';
				}

				if($layout == 'interactive-image') { //interactive-image

					return '<div style="width: '.$item_width.'px;height: '.$item_height.'px;" class="fap-cover-wrapper fap-grid-item fap-interactive-image">'.$thumbnail_html.'<div><div class="fap-item-title">'.$title.'</div><div class="fap-item-buttons"><a href="'.$url.'" title="'.htmlspecialchars($title) .'" rel="'.$cover.'" target="'.$share_link.'" data-meta="'.$unique_id_meta.'" class="'.$general_options['play_css_class'].' fap-single-track" data-autoenqueue="'.$auto_enqueue.'">'.$play_button_html.'</a>'.$enqueue_html.''.$referral_link_html.'</div>'.$meta_html.'</div></div>';

				}
				else if($layout == 'grid') { //grid

					return '<div class="fap-grid-item"><div style="width: '.$item_width.'px;height: '.$item_height.'px;" class="fap-cover-wrapper">'.$thumbnail_html.'</div><div class="fap-track-content" style="width: '.$item_width.'px;"><div class="fap-item-title">'.$title.'</div><div class="fap-item-meta">'.$meta.'</div><div class="fap-item-buttons"><a href="'.$url.'" title="'.htmlspecialchars($title) .'" rel="'.$cover.'" target="'.$share_link.'" data-meta="'.$unique_id_meta.'" class="'.$general_options['play_css_class'].' fap-single-track" data-autoenqueue="'.$auto_enqueue.'">'.$play_button_html.'</a>'.$enqueue_html.''.$referral_link_html.'</div></div>'.$meta_html.'</div>';

				}
				else if($layout == 'list') { //list

					return '<div class="fap-list-item fap-clearfix"><div style="width: '.$item_width.'px;height: '.$item_height.'px;" class="fap-cover-wrapper">'.$thumbnail_html.'</div><div class="fap-track-content" style="width: calc(100% - '.$item_width.'px - 20px);"><div class="fap-item-title">'.$title.'</div><div class="fap-item-meta">'.$meta.'</div><div  class="fap-item-buttons"><a href="'.$url.'" title="'.htmlspecialchars($title) .'" rel="'.$cover.'" target="'.$share_link.'" data-meta="'.$unique_id_meta.'" class="'.$general_options['play_css_class'].' fap-single-track" data-autoenqueue="'.$auto_enqueue.'">'.$play_button_html.'</a>'.$enqueue_html.''.$referral_link_html.'</div></div>'.$meta_html.'</div>';

				}
				else { //grid-icon, list-icon

					$grid_class = $layout == 'grid-icon' ? 'fap-grid-item' : 'fap-list-item';

					return '<div class="'.$grid_class.' fap-icons fap-clearfix"><div style="width: '.$item_width.'px;height: '.$item_height.'px;" class="fap-cover-wrapper">'.$thumbnail_html.'</div><div class="fap-track-content"><div class="fap-item-meta">'.$meta.'</div><div class="fap-item-title">'.$title.'</div></div><div class="fap-item-buttons"><a href="'.$url.'" title="'.htmlspecialchars($title) .'" rel="'.$cover.'" target="'.$share_link.'" data-meta="'.$unique_id_meta.'" class="'.$general_options['play_css_class'].' fap-single-track" data-autoenqueue="'.$auto_enqueue.'"><span class="fap-icon-play"></span></a>'.$enqueue_html.''.$referral_link_html.'</div>'.$meta_html.'</div>';

				}

			}

		}

	}

}

new FAP_Frontend();

?>