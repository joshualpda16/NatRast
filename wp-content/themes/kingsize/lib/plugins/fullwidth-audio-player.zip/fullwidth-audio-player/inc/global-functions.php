<?php

function fap_int_to_bool( $value ) {
	return empty($value) ? 0 : 1;
}

function fap_decode_to_html( $value ) {
	return str_replace("'", '"', htmlspecialchars_decode( stripslashes($value) ) );
}

function fap_check_options_availability( $options ) {

	foreach(FullwidthAudioPlayer::get_default_audio_player_options() as $key => $value) {
		$options[$key] = $options[$key] === null ? $value : $options[$key];
	}

	return $options;

}

?>